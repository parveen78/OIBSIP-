import pandas as pd
import requests
from bs4 import BeautifulSoup
Product_name=[]
Prices = []
Description = []
Reviews = []
for i in range(2,12):
    url = "https://www.flipkart.com/search?q=mobile+under+15000+rs&as=on&as-show=on&otracker=AS_Query_OrganicAutoSuggest_1_13_na_na_na&otracker1=AS_Query_OrganicAutoSuggest_1_13_na_na_na&as-pos=1&as-type=HISTORY&suggestionId=mobile+under+15000+rs&requestId=2de19a73-c8fc-43ba-9dfa-008b4c3a4219&page=" + str(
        i)
    # step 1 :get the html
    r = requests.get(url)
    # rint(r)
    soup = BeautifulSoup(r.text, "lxml")
    box = soup.find("div", class_="_1YokD2 _3Mn1Gg")

    name = box.find_all("div", class_="_4rR01T")
    for i in name:
        name = i.text
        Product_name.append(name)

    price = box.find_all("div", class_="_30jeq3 _1_WHN1")
    for i in price:
        name = i.text
        Prices.append(name)

    # print(Product_name)
    # print(Prices)

    Desc = box.find_all("ul", class_="_1xgFaf")
    for i in Desc:
        name = i.text
        Description.append(name)
    # print(Description)

    reviews = box.find_all("div", class_="_3LWZlK")
    for i in reviews:
        name = i.text
        Reviews.append(name)

    # print(Reviews)

# now we crearte a dataframe
flipkart=pd.DataFrame({"Product Name":Product_name,
                       "Prices":Prices,
                       "Discriptions":Description,
                       "Reviews":Reviews}
                      )
print(flipkart)
flipkart.to_csv("Flipkart_mobile_under_50000.csv")



























# while True
# np = soup.find("a", class_="_1LKTO3").get("href")
# Cnp = "https://www.flipkart.com" + np
# print(Cnp)

# url = Cnp
# r = requests.get(url)
# soup - BeautifulSoup(r.text, "lxml")